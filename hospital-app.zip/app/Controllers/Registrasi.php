<?php
namespace App\Controllers;
class Registrasi extends BaseController {
    public function index() {
        return view('registrasi');
    }
}