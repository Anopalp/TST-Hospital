<?php
namespace App\Controllers;

class RiwayatPenjualanObat extends BaseController {
    public function index() {
        return view('riwayatPenjualanObat');
    }
}