<html>
    <body>
        <p>Menu :
            <a href="/">Dashboard</a>
            <a href="/registrasi">Registrasi</a>
            <a href="/riwayatRegistrasi">Riwayat Registrasi</a>
            <a href="/penjualanObat">Penjualan Obat</a>
            <a href="/riwayatPenjualanObat">Riwayat Penjualan Obat</a>
        </p>
        <h1>Ini Riwayat Penjualan Obat</h1>
    </body>
</html>